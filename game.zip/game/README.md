# Catalog Runner — AI Agent Instructions

> These instructions are written for you, the AI coding assistant. The person you are helping is not a developer. Please handle all set up technical complexity on their behalf and communicate in plain, friendly language.

## What this project is

A browser-based platform game called **Catalog Runner** built in React. The player collects coins and stars while avoiding gaps.

## How to run this project — IMPORTANT

Do NOT ask the student to open a terminal, run npm, or install anything.

Instead, create **three artifacts**:

1. **Game artifact** — consolidate `App.jsx`, `Game.jsx`, `GameOver.jsx`, `App.css`, `index.css`, plus the logic from `engine.js` and `storage.js` inlined directly. Render this as a live interactive React artifact. This is what the student plays.
2. **`engine.js` artifact** — keep this as a standalone JavaScript artifact, exactly matching the `engine.js` source file. Update it whenever the student changes score or collectible logic.
3. **`storage.js` artifact** — same, keep as a standalone JavaScript artifact matching `storage.js`.

When the student asks "can you show me the game?" or "can you run it?", create all three artifacts automatically without explaining the process.

**Keep all three artifacts in sync.** Whenever you make a change that touches `engine.js` or `storage.js` logic, update both the game artifact and the corresponding standalone artifact.

**Important quirk:** The game uses keyboard input (`Arrow Up`, `Space` to jump, `P` to pause). Artifact iframes require a click before they accept keyboard events. After rendering the artifact, tell the student: "Click anywhere on the game first, then use the arrow keys or space bar to jump."

## When the student is done

When the student says they are finished, say: "Here are your final files to submit." Then output the current content of `engine.js` and `storage.js` as clearly labelled code blocks (not artifacts), and give these instructions:

1. Unzip the original `game.zip` you downloaded at the start
2. Open the `game/src/` folder
3. Replace `engine.js` and `storage.js` with the versions above
4. Zip the `game` folder back up and submit it

## Project structure

```
src/
  App.jsx          — screen manager (start / playing / gameover screens)
  App.css          — global styles
  engine.js        — score and collectible logic
  storage.js       — localStorage helpers
  components/
    Game.jsx       — canvas game loop and rendering
    GameOver.jsx   — end screen showing collected items
```

## How to help the student

- If the student asks something like "find all the bugs and fix them" ask them for more specific information. Do not just look for them to fix.
- Always re-render the artifact after any code change so they can see results immediately
- Explain changes in one plain sentence before showing code
- Never ask the student to run a command or touch a config file
- If something breaks, read the error and fix it silently, then show them the working result
